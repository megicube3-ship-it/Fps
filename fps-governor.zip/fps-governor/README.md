# FPS Governor (Fabric 1.21.11, client-only)

Auto-tuner FPS. Tiap detik mengukur FPS nyata (hook di `MinecraftClient.render`), lalu:

- FPS < target  -> turunkan "level kualitas" 1 tingkat (render distance, entity distance, partikel)
- FPS aman      -> naikkan lagi, hanya bila prediksi FPS setelah naik masih di atas target
- Level yang ternyata TIDAK menaikkan FPS langsung di-undo dan diblokir (backoff), jadi tidak ada flicker
- Sadar shader: target berbeda saat Iris shader pack aktif (default 40 FPS, tanpa shader 60)
- Pengaturan asli kamu selalu dipulihkan saat keluar server / game ditutup / `/fpsgov off`
- Kalau kamu ubah pengaturan sendiri, governor ikut dan mulai ulang dari nilai barumu
- Tidak pernah menaikkan di atas nilai asli kamu; batas FPS (max framerate) kamu dihormati

## Build (GitHub Actions)
1. Upload semua isi folder ini ke repo GitHub (struktur folder dipertahankan, termasuk `.github/workflows/build.yml`).
2. Tab **Actions** -> workflow **build** -> tunggu hijau -> **Artifacts** -> `fps-governor-jar`.
3. Ambil `fps-governor-1.0.0.jar`, taruh di folder `mods`. Butuh Fabric API.

Di PC: `gradle build` (Gradle 9.2+, JDK 21) -> `build/libs/fps-governor-1.0.0.jar`.

## Perintah (ketik di chat)
- `/fpsgov status` : level, FPS 5 detik, target, nilai asli vs sekarang
- `/fpsgov on` / `off` / `reset`
- `/fpsgov target <fps>` : target tanpa shader
- `/fpsgov shadertarget <fps>` : target dengan shader
- `/fpsgov minrd <chunk>` : render distance minimum

Config: `.minecraft/config/fpsgovernor.json` (mulai otomatis setelah warmup 20 detik masuk server).

## Kalau error
Kirim `latest.log`. Cari baris `[FPS Governor]`. Bila ada peringatan "hook frame tidak terpasang",
nama method `render` di MinecraftClient berubah dan mixin perlu disesuaikan (mod tidak crash, hanya idle).
